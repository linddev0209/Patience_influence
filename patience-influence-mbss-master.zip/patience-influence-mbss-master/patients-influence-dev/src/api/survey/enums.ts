/* eslint-disable no-shadow */
export enum SurveyType {
  Questionnaire,
  Short_Interview,
  Long_Interview,
}

export enum QuestionType {
  ShortAnswer,
  Paragraph,
  MultipleChoice,
  SingleChoice,
}
