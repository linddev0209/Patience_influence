export type TCreateStakeholderParams = {
  username: string;
  userId: number;
};
