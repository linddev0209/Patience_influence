export type TCreateLocation = {
  name: string;
  countryId: string;
  isCommon: boolean;
};

export type TSingleLocation = {
  id: number;
};
