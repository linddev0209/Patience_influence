declare module '*.ttf';
declare module '*.otf';
