import styled from '@emotion/styled';

export const BubbleChartMain = styled.div`
  min-width: 450px;
  width: 100%;
  height: 100%;
  position: relative;
`;
