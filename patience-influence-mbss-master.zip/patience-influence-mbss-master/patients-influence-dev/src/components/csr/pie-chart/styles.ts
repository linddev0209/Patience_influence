import styled from '@emotion/styled';

export const PieChartMain = styled.div`
  width: 100%;
  height: 250px;
  position: relative;
`;
