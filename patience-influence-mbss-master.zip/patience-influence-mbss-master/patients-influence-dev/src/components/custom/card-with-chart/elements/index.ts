export { default as PercentIndicator } from 'components/custom/card-with-chart/elements/percent-indicator';
