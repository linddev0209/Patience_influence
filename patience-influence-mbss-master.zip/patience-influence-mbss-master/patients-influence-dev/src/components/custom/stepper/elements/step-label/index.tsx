import React from 'react';

import { StepLabelMain } from 'components/custom/stepper/elements/step-label/style';

const StepLabel = ({ ...props }) => <StepLabelMain {...props} />;

export default StepLabel;
