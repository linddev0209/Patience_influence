import styled from '@emotion/styled';

export const SubmitFormModal = styled.div`
  width: 100%;
`;
