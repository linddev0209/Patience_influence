import { StepLabelProps } from '@mui/material';

export type TStepLabelProps = StepLabelProps;
