import { StepProps } from '@mui/material';

export type TStepProps = StepProps;

export type TStepRef = HTMLDivElement;
