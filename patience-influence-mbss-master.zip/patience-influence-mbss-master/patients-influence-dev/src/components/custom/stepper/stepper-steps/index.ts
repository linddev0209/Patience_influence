export { default as Step1 } from 'components/custom/stepper/stepper-steps/step-1';
export { default as Step2 } from 'components/custom/stepper/stepper-steps/step-2';
export { default as Step3 } from 'components/custom/stepper/stepper-steps/step-3';
export { default as Step4 } from 'components/custom/stepper/stepper-steps/step-4';
export { default as StepV } from 'components/custom/stepper/stepper-steps/step-verified';
