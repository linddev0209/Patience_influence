import React from 'react';

export type TTitleProps = React.HTMLAttributes<HTMLDivElement> & {
  title: string;
};
