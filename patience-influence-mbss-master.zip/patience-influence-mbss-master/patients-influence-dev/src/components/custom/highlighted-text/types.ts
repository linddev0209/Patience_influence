import React from 'react';

export type THighlightedTextProps = React.HTMLAttributes<HTMLDivElement> & {};
