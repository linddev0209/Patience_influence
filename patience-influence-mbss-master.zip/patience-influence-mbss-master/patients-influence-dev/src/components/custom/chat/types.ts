export interface ChatProps {
  chatRoomId: any;
  isPingActive?: boolean;
}
