export { default as ChatMessage } from 'components/custom/chat/elements/chat-message';
