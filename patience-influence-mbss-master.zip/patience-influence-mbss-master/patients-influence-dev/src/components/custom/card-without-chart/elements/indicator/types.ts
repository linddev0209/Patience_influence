import React from 'react';

export type TIndicatorProps = React.HTMLAttributes<HTMLDivElement> & {
  percent: number;
};
