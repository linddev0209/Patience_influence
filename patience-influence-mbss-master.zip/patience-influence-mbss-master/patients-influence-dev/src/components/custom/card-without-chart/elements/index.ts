export { default as Indicator } from 'components/custom/card-without-chart/elements/indicator';
