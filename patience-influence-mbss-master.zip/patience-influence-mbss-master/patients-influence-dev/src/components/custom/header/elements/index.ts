export { default as SignUpModal } from 'components/custom/header/elements/sign-up-modal';
