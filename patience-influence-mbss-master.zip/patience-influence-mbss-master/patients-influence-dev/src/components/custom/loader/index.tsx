import React from 'react';
import { LoaderMain } from 'components/custom/loader/styles';

const Loader = () => <LoaderMain />;

export default Loader;
