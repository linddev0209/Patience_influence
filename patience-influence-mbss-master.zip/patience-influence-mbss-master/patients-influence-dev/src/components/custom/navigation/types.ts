import React from 'react';

export type TNavigationProps = React.HTMLAttributes<HTMLDivElement>;
