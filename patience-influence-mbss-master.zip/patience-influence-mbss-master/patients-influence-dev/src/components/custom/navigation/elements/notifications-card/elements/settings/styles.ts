import styled from '@emotion/styled';
import { Grid } from 'components/system';

export const NotificationSettingsMain = styled(Grid)`
  width: 100%;
`;
