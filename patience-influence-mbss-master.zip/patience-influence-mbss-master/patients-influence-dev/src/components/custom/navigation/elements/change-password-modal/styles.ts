import styled from '@emotion/styled';
import { Grid } from 'components/system';

export const ChangePasswordModalMain = styled(Grid)`
  width: 100%;
`;
