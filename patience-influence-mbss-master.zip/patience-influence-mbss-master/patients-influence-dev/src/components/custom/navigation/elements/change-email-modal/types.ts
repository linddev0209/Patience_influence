import React from 'react';

export type TChangeEmailModalProps = React.HTMLAttributes<HTMLDivElement> & {
  onClose: () => void;
};
