export { default as ProgressDisplay } from 'components/custom/card-with-progress/elements/progress-display';
