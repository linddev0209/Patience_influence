import React from 'react';

export type TNumberIndicatorProps = React.HTMLAttributes<HTMLDivElement> & {
  number: number;
};
