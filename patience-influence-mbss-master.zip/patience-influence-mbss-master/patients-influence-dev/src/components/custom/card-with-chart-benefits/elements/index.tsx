export { default as NumberIndicator } from 'components/custom/card-with-chart-benefits/elements/number-indicator';
