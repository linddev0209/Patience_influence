export const DTimeTableCellClasses = {
  cell: '.Cell-cell',
};
