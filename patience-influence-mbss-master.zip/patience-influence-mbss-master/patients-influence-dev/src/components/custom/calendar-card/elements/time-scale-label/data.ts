export const DTimeScaleLabelClasses = {
  label: '.Label-label',
  labelText: '.Label-text',
  emptyLabel: '.Label-emptyLabel',
};
