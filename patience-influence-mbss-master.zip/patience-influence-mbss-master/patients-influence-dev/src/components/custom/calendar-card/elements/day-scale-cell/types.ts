import { WeekView } from '@devexpress/dx-react-scheduler-material-ui';

export type TDayScaleCellProps = WeekView.DayScaleCellProps;
