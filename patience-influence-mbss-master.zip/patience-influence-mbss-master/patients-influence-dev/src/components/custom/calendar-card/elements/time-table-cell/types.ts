import { WeekView } from '@devexpress/dx-react-scheduler-material-ui';

export type TTimeTableCellProps = WeekView.TimeTableCellProps & {};
