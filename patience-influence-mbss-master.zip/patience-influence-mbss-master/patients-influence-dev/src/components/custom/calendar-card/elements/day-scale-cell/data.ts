export const DDayScaleCellClasses = {
  dayView: '.Cell-dayView',
  dayOfWeek: '.Cell-dayOfWeek',
  dayOfMonth: '.Cell-dayOfMonth',
  highlightedText: '.Cell-highlightedText',
};
