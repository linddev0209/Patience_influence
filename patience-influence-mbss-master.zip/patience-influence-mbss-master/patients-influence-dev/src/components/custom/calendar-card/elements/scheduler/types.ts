import { TModalProps } from 'components/custom/modal/types';

export type TSchedulerProps = TModalProps & {
  date: Date;
};
