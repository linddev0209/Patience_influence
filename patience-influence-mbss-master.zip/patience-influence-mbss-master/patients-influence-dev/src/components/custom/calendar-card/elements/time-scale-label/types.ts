import { WeekView } from '@devexpress/dx-react-scheduler-material-ui';

export type TTimeScaleLabelProps = WeekView.TimeScaleLabelProps;
