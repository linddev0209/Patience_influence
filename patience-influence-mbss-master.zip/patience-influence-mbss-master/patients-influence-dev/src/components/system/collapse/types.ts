import { CollapseProps } from '@mui/material';

export type TCollapseProps = CollapseProps & {
  removeGap?: boolean;
};
