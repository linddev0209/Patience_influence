import React from 'react';

export type TBadgeProps = React.HTMLAttributes<HTMLDivElement>;
