import React from 'react';

export type TitleType = {
  children: React.ReactNode;
};
